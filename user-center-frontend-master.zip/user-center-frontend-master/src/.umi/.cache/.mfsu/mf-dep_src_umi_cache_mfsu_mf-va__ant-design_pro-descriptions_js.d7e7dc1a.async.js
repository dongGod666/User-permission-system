(self["webpackChunkant_design_pro"] = self["webpackChunkant_design_pro"] || []).push([["mf-dep_src_umi_cache_mfsu_mf-va__ant-design_pro-descriptions_js"],{

/***/ "./src/.umi/.cache/.mfsu/mf-va_@ant-design_pro-descriptions.js":
/*!*********************************************************************!*\
  !*** ./src/.umi/.cache/.mfsu/mf-va_@ant-design_pro-descriptions.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FieldRender": function() { return /* reexport safe */ _ant_design_pro_descriptions__WEBPACK_IMPORTED_MODULE_0__.FieldRender; },
/* harmony export */   "ProDescriptions": function() { return /* reexport safe */ _ant_design_pro_descriptions__WEBPACK_IMPORTED_MODULE_0__.ProDescriptions; }
/* harmony export */ });
/* harmony import */ var _ant_design_pro_descriptions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ant-design/pro-descriptions */ "./node_modules/@ant-design/pro-descriptions/es/index.js");

/* harmony default export */ __webpack_exports__["default"] = (_ant_design_pro_descriptions__WEBPACK_IMPORTED_MODULE_0__.default);



/***/ })

}]);