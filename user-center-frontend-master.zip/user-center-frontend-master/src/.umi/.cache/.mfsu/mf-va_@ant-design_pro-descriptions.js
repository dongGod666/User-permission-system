import _ from '@ant-design/pro-descriptions';
export default _;
export * from '@ant-design/pro-descriptions';
