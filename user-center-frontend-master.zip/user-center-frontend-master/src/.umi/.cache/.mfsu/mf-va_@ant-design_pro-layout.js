import _ from '@ant-design/pro-layout';
export default _;
export * from '@ant-design/pro-layout';
