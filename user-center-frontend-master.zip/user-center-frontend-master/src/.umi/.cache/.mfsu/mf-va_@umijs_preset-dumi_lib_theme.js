export * from '@umijs/preset-dumi/lib/theme';
