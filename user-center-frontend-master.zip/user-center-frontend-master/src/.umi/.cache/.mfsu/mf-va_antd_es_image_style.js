import 'D:/planet/用户中心/user-center-frontend-master/node_modules/antd/es/image/style';
