import _ from 'D:/planet/用户中心/user-center-frontend-master/node_modules/antd/es/spin';
export default _;
