import _ from 'D:/planet/用户中心/user-center-frontend-master/node_modules/core-js';
export default _;
export * from 'D:/planet/用户中心/user-center-frontend-master/node_modules/core-js';
