import _ from 'D:/planet/用户中心/user-center-frontend-master/node_modules/dumi-theme-default/es/builtins/Badge.js';
export default _;
