import _ from 'D:/planet/用户中心/user-center-frontend-master/node_modules/@umijs/preset-built-in/node_modules/regenerator-runtime/runtime.js';
export default _;
export * from 'D:/planet/用户中心/user-center-frontend-master/node_modules/@umijs/preset-built-in/node_modules/regenerator-runtime/runtime.js';
